/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_1687431684")

  // remove field
  collection.fields.removeById("json1441701229")

  // add field
  collection.fields.addAt(9, new Field({
    "cascadeDelete": false,
    "collectionId": "pbc_3634962183",
    "hidden": false,
    "id": "relation1441701229",
    "maxSelect": 1,
    "minSelect": 0,
    "name": "classement",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "relation"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_1687431684")

  // add field
  collection.fields.addAt(9, new Field({
    "hidden": false,
    "id": "json1441701229",
    "maxSize": 0,
    "name": "classement",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "json"
  }))

  // remove field
  collection.fields.removeById("relation1441701229")

  return app.save(collection)
})
