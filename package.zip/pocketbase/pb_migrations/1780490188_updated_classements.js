/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3634962183")

  // remove field
  collection.fields.removeById("bool271442091")

  // add field
  collection.fields.addAt(4, new Field({
    "hidden": false,
    "id": "number271442091",
    "max": null,
    "min": null,
    "name": "done",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3634962183")

  // add field
  collection.fields.addAt(2, new Field({
    "hidden": false,
    "id": "bool271442091",
    "name": "done",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "bool"
  }))

  // remove field
  collection.fields.removeById("number271442091")

  return app.save(collection)
})
