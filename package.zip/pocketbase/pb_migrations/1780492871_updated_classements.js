/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_3634962183")

  // remove field
  collection.fields.removeById("number666537513")

  // remove field
  collection.fields.removeById("number271442091")

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_3634962183")

  // add field
  collection.fields.addAt(1, new Field({
    "hidden": false,
    "id": "number666537513",
    "max": null,
    "min": null,
    "name": "points",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  // add field
  collection.fields.addAt(3, new Field({
    "hidden": false,
    "id": "number271442091",
    "max": null,
    "min": null,
    "name": "done",
    "onlyInt": false,
    "presentable": false,
    "required": false,
    "system": false,
    "type": "number"
  }))

  return app.save(collection)
})
