/// <reference path="../pb_data/types.d.ts" />
migrate((app) => {
  const collection = app.findCollectionByNameOrId("pbc_4177893232")

  // update field
  collection.fields.addAt(2, new Field({
    "hidden": false,
    "id": "select989021800",
    "maxSelect": 1,
    "name": "categories",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "select",
    "values": [
      "Reflex",
      "Articulation",
      "Mémoire",
      "Équilibre"
    ]
  }))

  return app.save(collection)
}, (app) => {
  const collection = app.findCollectionByNameOrId("pbc_4177893232")

  // update field
  collection.fields.addAt(2, new Field({
    "hidden": false,
    "id": "select989021800",
    "maxSelect": 1,
    "name": "categories",
    "presentable": false,
    "required": false,
    "system": false,
    "type": "select",
    "values": [
      "reflex",
      "equilibre",
      "articulation",
      "memoire"
    ]
  }))

  return app.save(collection)
})
